/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author penguinlips
 */
public class DBconnection {
    public static Connection getConnection() throws SQLException{
        Connection c = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            c = DriverManager.getConnection("jdbc:mysql://localhost:3306/data","enter username","enter password");
            System.out.println("success");
            
        }catch (ClassNotFoundException | SQLException e){
        }
            return c;
        }
    public static Statement createStatement(){
        throw new UnsupportedOperationException("Not supported");
    }
}
